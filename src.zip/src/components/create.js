import React from 'react'

const create = ()=> {
    const{handleSubmit , register, reset} = useForm()
    const navigate = useNavigate()
    const addData = (data) => {
        const response = axios.post("url", data)
        alert("data added", data)
        reset()
        navigate("/list")

    }
    return(
        <>
        <form onSubmit={handleSubmit(addData)}>
            <label>Add Event</label>
            <input id ="add" {...register("eventname")}/>
            <button>Add Event</button>
            </form></>
    )
}
