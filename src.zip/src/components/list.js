import { useEffect, useState } from "react"

const List = ()=> {
    const [add, setAdd] = useState([])
    const fetchData = async() => {
        const response = await axios.get("DBJSON URL")
        const result = await response.data
        setAdd(result)
    }
    useEffect(() => {
        fetchData()
    },[])
    return (
        <>
        <table className="table">
            <thead>
                <tr>
                    <th>Event Name</th>
                    <th>Id</th>
                    <th>Date</th>
                    <th>Location</th>
                    
                    

                </tr>

            </thead>
            <tbody>
                {
                    add.map((elem) => {
                        return <>
                        <tr>
                            <td>{elem.eventname}</td>
                            <td>{elem.id}</td>
                            <td>{elem.date}</td>
                            <td>{elem.location}</td>
                        </tr>
                        </>
                    })
                }
            </tbody>
            
        </table>
        </>
    )
}