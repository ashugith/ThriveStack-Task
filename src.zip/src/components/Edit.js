import { useEffect } from "react"

const Edit= ()=> {
    const{id} = useparams()
    const {handleSubmit , register , setValue} = useForm()
    const navigate = useNavigate()
    const fetchData = async() => {
        const response = await axios.get(`dbjson link/${id}`)
        setValue("eventname" , response.data.eventname)
    }
    useEffect(() => {
        fetchData()
    },[])
    const addData = (data) => {
        const response = axios.put(`dbjson link/${id},data`)
        alert("data updated")

    }

    return(
        <>
        <form onSubmit={handleSubmit(addData)}>
            <button>Update</button>

        </form>
        </>
    )

    


}